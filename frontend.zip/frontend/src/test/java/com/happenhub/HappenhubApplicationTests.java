package com.happenhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HappenhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
