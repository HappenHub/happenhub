import React from 'react';
import { Link } from 'react-router-dom';

const EventCard = ({ event }) => {
  return (
    <div className="event-card">
      <img 
        src={event.imageUrl || '/default-event.jpg'} 
        alt={event.name}
        className="w-full h-48 object-cover rounded-t-lg"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{event.name}</h3>
        <p className="text-gray-600 mb-2">{event.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-primary font-medium">${event.price}</span>
          <Link 
            to={`/event/${event.id}`}
            className="px-4 py-2 bg-primary text-white rounded hover:bg-accent transition-colors"
          >
            View Details
          </Link>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {event.tags?.map((tag, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-gray-100 text-sm rounded-full text-gray-600"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventCard;